Evaluate whether the macOS menu bar app satisfies the requested implementation and release criteria.

Template context

- App name: [APP_NAME]
- Core functionality: [FUNCTIONALITY GOES HERE]

Acceptance checklist

Project generation

- xcodegen generate succeeds
- project.yml is complete and does not require manual editing after generation

Builds

- Debug build succeeds without signing
- Release build succeeds with local signing config
- Required packages resolve successfully

Secrets hygiene

- Signing.xcconfig is not committed
- Signing.xcconfig.example is committed
- .gitignore excludes local signing config and normal Xcode artifacts

Signing and entitlements

- Bundle identifier is realistic and non-placeholder
- Automatic signing is configured sanely for local development
- Any required entitlements are included in the final installed app
- If a post-build re-sign step is required, it works and verifies the app before copying to /Applications

Permissions

- All required NS...UsageDescription keys are present
- Required permission request flows are implemented
- Relevant System Settings links exist if useful
- If needed, a real test action exists to trigger TCC registration

Menu bar behavior

- MenuBarExtra is used
- Idle and active icons reflect runtime state correctly
- Primary and stop or secondary actions behave correctly
- Status text updates sensibly
- Preferences and Quit are present

Preferences

- Preferences open reliably
- Header uses toolbar-style tabs with icons above labels
- General tab covers common app settings
- Product-specific feature tab exists and is coherent
- Privacy tab exposes permission status and actions

Core product behavior

- [FUNCTIONALITY GOES HERE] is implemented end to end
- user-visible errors are understandable
- invalid states are handled cleanly

Persistence and output

- settings persist between launches where appropriate
- any output path, file format, or generated artifact behavior works as expected

Tests

- unit tests exist for settings persistence
- unit tests exist for core domain behavior
- unit tests exist for file or output formatting if applicable
- tests pass

Output format

Return one of the following:

- PASS: if all critical criteria are met
- FAIL: if any critical criteria are not met

Then provide:

- failed criteria, if any
- risks or gaps
- concise recommendation for next steps
