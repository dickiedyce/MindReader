You are building a complete native macOS menu bar app called [APP_NAME].

Your job is to create the application from scratch, not just sketch it. Produce the code, tests, configuration, and project structure needed for a working macOS app that can be opened in Xcode, built, signed locally, and installed into /Applications.

Product brief

Build a native macOS SwiftUI menu bar application that:

- implements [FUNCTIONALITY GOES HERE]
- runs fully locally unless explicitly told otherwise
- exposes a polished Preferences window with a native macOS toolbar-style tab layout
- supports configurable global keyboard shortcuts if relevant to the app
- handles required macOS privacy permissions correctly
- avoids committing signing secrets or local machine-specific config

Non-negotiable platform requirements

- Target macOS only
- Use Swift 5.10
- Minimum deployment target: macOS 13.0
- Use SwiftUI
- Use MenuBarExtra for the menu bar experience
- Use XcodeGen to generate the Xcode project
- Minimum XcodeGen version: 2.38.0
- Prefer generated Info.plist settings from build settings
- The repo must build with xcodegen generate followed by xcodebuild

Expected project layout

- [APP_NAME]/Sources/App
- [APP_NAME]/Sources/Models
- [APP_NAME]/Sources/Services
- [APP_NAME]/Resources
- [APP_NAME]/Config
- [APP_NAME]Tests

Expected core types

- [APP_NAME]App
- MenuBarView
- MenuBarViewModel
- PreferencesView
- PreferencesWindowController
- AppSettings
- [DOMAIN_SERVICE_TYPES GO HERE]
- ShortcutNames

Menu bar behavior

- The app lives in the menu bar
- Use waveform.circle when idle
- Use waveform.circle.fill while the app is actively performing its primary live action, or substitute a more suitable icon only if explicitly required
- The menu should show:
  - app name
  - short status text
  - primary action
  - secondary or stop action if applicable
  - Preferences...
  - Quit
- Disable actions when they are not currently valid
- Avoid duplicate work while processing

Preferences requirements

The Preferences window must feel like a real macOS settings surface, not a generic form.

Window behavior

- Open via an explicit Preferences menu item
- If the default selector-based settings path is unreliable, use a dedicated PreferencesWindowController hosting SwiftUI
- Reopen cleanly instead of spawning duplicates

Tab styling

- Toolbar-style header with icons above labels
- Even spacing across the full width
- Divider below the header
- Active tab highlighted with accent color
- Inactive tabs styled with secondary color
- Avoid chunky pill backgrounds unless the product explicitly wants them

Minimum tabs

1. General

- app-wide settings
- output location or storage settings if applicable
- keyboard shortcuts if applicable

2. [FEATURE TAB NAME]

- [FEATURE-SPECIFIC SETTINGS GO HERE]

3. Privacy

- rows showing relevant permission state
- buttons to request permissions
- buttons to open the relevant System Settings panes
- any explicit test action required to force TCC registration if the app depends on microphone, camera, screen capture, accessibility, speech recognition, or similar permissions
- short explanation of local data handling

Privacy, permissions, and entitlements

Determine the exact privacy requirements for [FUNCTIONALITY GOES HERE] and implement them correctly.

Requirements

- Set all required NS...UsageDescription keys via build settings
- Create an entitlements file if required by the chosen functionality
- If Hardened Runtime is enabled for a signed build, ensure all needed entitlements are present in the final installed app, not just the build product
- If the app uses microphone input, include com.apple.security.device.audio-input = true
- If other capabilities are needed, add only the minimum required entitlements

Signing and secrets handling

This app must support local signing while keeping secrets out of git.

Requirements

- Create [APP_NAME]/Config/Signing.xcconfig.example and commit it
- Create [APP_NAME]/Config/Signing.xcconfig locally only
- Ensure Signing.xcconfig is gitignored
- Put machine-specific signing values only in Signing.xcconfig
- Example local signing template should include DEVELOPMENT_TEAM and CODE_SIGN_IDENTITY
- Support Apple Development signing locally
- Allow local override to Developer ID Application for distribution builds

XcodeGen requirements

Create a project.yml that includes:

- Swift version 5.10
- macOS deployment target 13.0
- app target and test target
- any required Swift packages
- generated Info.plist keys for permissions and app display name
- CODE_SIGN_ENTITLEMENTS if entitlements are needed
- Debug config with:
  - CODE_SIGNING_ALLOWED = NO
  - CODE_SIGNING_REQUIRED = NO
  - CODE_SIGN_IDENTITY = empty
- config files for Debug and Release pointing at Signing.xcconfig

Post-build install behavior

Add a post-build script that:

- checks whether code signing is enabled
- checks whether a signing identity exists
- re-signs the built app explicitly with the entitlements file when needed
- verifies the final signature
- copies the signed app to /Applications using ditto

This is specifically to avoid common macOS signing failures where the installed app does not contain the required entitlements.

Testing requirements

Use TDD.

That means:

- write failing tests first
- implement the minimum code to make them pass
- refactor only as needed

At minimum include tests for:

- AppSettings persistence
- any file-writing or output formatting logic
- any core domain logic for [FUNCTIONALITY GOES HERE]
- permission or configuration edge cases where unit testing is practical

Add UI tests where the product has meaningful UI workflows.

Git and secrets hygiene

- Do not commit Signing.xcconfig
- Do commit Signing.xcconfig.example
- Do commit project.yml
- Do commit entitlements when applicable
- Do not commit build artifacts, local caches, or machine-specific files
- Provide a .gitignore suitable for Xcode/macOS development

Implementation style

- Keep the code modest and understandable
- Prefer small focused types over over-engineered abstractions
- Add comments only for non-obvious behavior
- Keep public APIs and naming straightforward
- Prefer fixing root causes rather than layering on workarounds

Execution requirements

Do not stop at planning. Actually create the app and ensure it builds.

If you need to make a design choice, choose the most pragmatic native macOS option and continue.

Before finishing, verify all of the following:

- xcodegen generate succeeds
- Debug build succeeds without signing
- Release build succeeds with local signing config
- the installed app in /Applications has the required entitlements
- preferences open reliably
- the menu bar UI reflects runtime state correctly
- tests pass
