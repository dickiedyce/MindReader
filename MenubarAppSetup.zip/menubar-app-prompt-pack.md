This folder contains reusable prompt templates for native macOS menu bar apps.

Files

- menubar-app-build.prompt.md
  Purpose: a tight execution prompt for another coding LLM to build the app from scratch.

- menubar-app-review.prompt.md
  Purpose: a review prompt focused on bugs, risks, signing, entitlements, permissions, UX mismatches, and missing tests.

- menubar-app-acceptance.prompt.md
  Purpose: a final acceptance gate to determine whether the implementation is actually complete.

Template placeholders

Replace these before use:

- [APP_NAME]
- [FUNCTIONALITY GOES HERE]
- [DOMAIN_SERVICE_TYPES GO HERE]
- [FEATURE TAB NAME]
- [FEATURE-SPECIFIC SETTINGS GO HERE]

Suggested workflow

1. Start with menubar-app-build.prompt.md to generate the app.
2. Run menubar-app-review.prompt.md against the generated code.
3. Run menubar-app-acceptance.prompt.md as the final ship gate.

Notes

- These templates keep the macOS-specific build, signing, entitlements, privacy, and preferences constraints intact.
- Product-specific behavior is intentionally abstracted so the pack can be reused for other menu bar apps.
