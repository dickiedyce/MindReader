Review the generated macOS menu bar app for correctness, macOS platform fit, and production readiness.

Project template context

- App name: [APP_NAME]
- Core functionality: [FUNCTIONALITY GOES HERE]
- Platform: macOS only
- UI stack: SwiftUI
- Project generation: XcodeGen
- Local signing: required

Review priorities

Focus on findings first. Prioritize:

- behavioral bugs
- signing and entitlements mistakes
- privacy and permissions mistakes
- broken build or project generation steps
- unsafe secrets handling
- mismatch between the requested Preferences UX and the implemented one
- missing tests or invalid TDD flow
- regressions in menu bar behavior or keyboard shortcuts

Review checklist

1. Project and build

- Does xcodegen generate work without manual repair?
- Does the project build in Debug without signing?
- Does Release build correctly with local signing config?
- Are package dependencies declared correctly?

2. Signing and security

- Is Signing.xcconfig excluded from git?
- Is Signing.xcconfig.example present and useful?
- Are bundle ID and signing settings realistic?
- If entitlements are required, are they present in the final installed app?
- Does the post-build script re-sign and verify correctly when needed?

3. Permissions and privacy

- Are all required NS...UsageDescription keys present?
- Are permission request flows implemented correctly for the app’s functionality?
- Are System Settings deep links provided where appropriate?
- If TCC registration requires a real test action, is that present?

4. Preferences UX

- Does the Preferences window open reliably?
- Is the header styled like a native macOS toolbar with icons above text?
- Are the tabs appropriate for the product?
- Are product-specific settings represented clearly rather than as placeholder developer controls?

5. Menu bar UX

- Does the menu bar icon reflect app state?
- Are primary and secondary actions separated correctly?
- Are invalid actions disabled?
- Do displayed shortcuts match configured shortcuts?

6. Code quality

- Is the structure small, coherent, and pragmatic?
- Are there any obvious race conditions, permission handling issues, or state bugs?
- Are comments minimal and useful?

7. Tests

- Are there meaningful unit tests for settings and core behavior?
- Are output-format or file-writing behaviors tested?
- Are any important edge cases untested?

Output format

Return:

- Findings ordered by severity, each with file references and a short explanation
- Open questions or assumptions
- Brief summary of overall readiness

If there are no findings, say so explicitly and mention any residual risks or testing gaps.
